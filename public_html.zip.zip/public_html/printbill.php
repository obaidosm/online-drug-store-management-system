<?php
		include "odsms_config.php";
		session_start();

		$ename=$_SESSION['user'];
		$uid=$_SESSION['uid'];

    if(isset($_GET['sid'])) 
		$sid=$_GET['sid'];
    ?>
<html>
<head>



<title>
Saleman POS SALES
</title>

</head>

<style>
#invoice-POS{
  box-shadow: 0 0 1in -0.25in rgba(0, 0, 0, 0.5);
  padding:2mm;
  margin: 0 auto;
  width: 70mm;
  background: #FFF;
  
  
::selection {background: #f31544; color: #FFF;}
::moz-selection {background: #f31544; color: #FFF;}
h1{
  font-size: 1.5em;
  color: #222;
}
h2{font-size: .9em;}
h3{
  font-size: 1.2em;
  font-weight: 300;
  line-height: 2em;
}
p{
  font-size: .7em;
  color: #666;
  line-height: 1.2em;
}
 
#top, #mid,#bot{ /* Targets all id with 'col-' */
  border-bottom: 1px solid #EEE;
}

#top{min-height: 100px;}
#mid{min-height: 80px;} 
#bot{ min-height: 50px;}

#top .logo{
  //float: left;
	height: 60px;
	width: 60px;
	background: url(http://michaeltruong.ca/images/logo1.png) no-repeat;
	background-size: 60px 60px;
}
.clientlogo{
  float: left;
	height: 60px;
	width: 60px;
	background: url(http://michaeltruong.ca/images/client.jpg) no-repeat;
	background-size: 60px 60px;
  border-radius: 50px;
}
.info{
  display: block;
  //float:left;
  margin-left: 0;
}
.title{
  float: right;
}
.title p{text-align: right;} 
#table{
  min-width: 265px;
  max-width: 100%;
  border-collapse: collapse;
}
td{
  //padding: 5px 0 5px 15px;
  //border: 1px solid #EEE
}
.tabletitle{
  //padding: 5px;
  font-size: .5em;
  background: #EEE;
}
.service{border-bottom: 1px solid #EEE;}
.item{width: 24mm;}
.itemtext{font-size: .5em;}

#legalcopy{
  margin-top: 5mm;
}

  
  
}
</style>

<body>

  <div id="invoice-POS">
    
    <center id="top">
      <div class="logo"> <img src="logo.png"</div>
      <div class="info"> 
        <h6> 55, Poonch Road Chouburgy Lhr</h6>
      </div><!--End Info-->
    </center><!--End InvoiceTop-->
    
    <div id="mid">
      <div style="text-align: center;">
        
       
       <ln >Invoice# <?php echo"$sid" ?></ln>
       
      
         <div><ln id="dt"></ln></div>
         <div style="text-align: left;" ><ln >Name:<ln id="demo"></ln></ln></div>
        
       
       
      </div>
      

    </div><!--End Invoice Mid-->

    <div id="bot">

					<div id="table">
		
		<table id='table1'>
		<tr style='outline: thin solid'>
		
			<th align="left">Name</th>
			<th>QTY</th>
			<th>@</th>
			<th>Amount</th>
		
		</tr>
	
	<?php
		$qry10="SELECT storeid from employee where userid='$uid'";
		$row10= $conn->query($qry10);
		$row9=$row10->fetch_row();
		$stid = $row9[0];

	
		if(isset($_GET['sid'])) {
		$sid=$_GET['sid'];}
		
	
	
		if(!empty($sid)) {
		$qry1 = "SELECT medid,saleqty,totprice FROM saleitem where saleid=$sid ";
		$result1 = $conn->query($qry1);
		$sum=0;

			if ($result1->num_rows > 0) {
	
			while($row1 = $result1->fetch_assoc()) {
		
					$medid=$row1["medid"];
					$qry2 = "SELECT medname,medprice FROM medicine where medid=$medid ";
					$result2 = $conn->query($qry2);
					$row2=$result2->fetch_row();
					
				echo "<tr style='outline: thin solid' align:'center'>";

					echo "<td>" . $row2[0]. "</td>";
					echo "<td>" . $row1["saleqty"]. "</td>";
					echo "<td>" . $row2[1]. "</td>";
					echo "<td align='right'>" . $row1["totprice"]. "</td>";
				echo "</tr>";
				}}
		}
			
			if(!empty($sid)) {
			
			$res=mysqli_query($conn,"SET @p1=$sid;");
			$res=mysqli_query($conn,"SET @p0=$stid");
			$res=mysqli_query($conn,"SET @p4=$uid");
			$res=mysqli_query($conn,"CALL `TOTAL_AMT`(@p0,@p1,@p2,@p4);") or die(mysqli_error($conn));
			$res=mysqli_query($conn,"SELECT @p2 as TOTAL;");
			
			while($row=mysqli_fetch_array($res))
			{
				$tot=$row['TOTAL'];
			}}
			?>
			<tr style="text-align: left";>
			    <th> Grand Total : </th>
			 
			    <th colspan="3"; style="text-align: right";><?php echo"$tot" ?></th>
			</tr>
		</table>
					</div><!--End Table-->

					<div id="legalcopy">
						<p class="legal"><strong>Thank you for your business!</strong> <br>
						<ln>-Sold goods will not be return.</ln>
						
						
						
						</p>
					</div>
					<div style="font-size: small; text-align: center; outline: thin solid";>
	Developed by: OSM 0304-7185855
</div>

				</div><!--End InvoiceBot-->
				
  </div><!--End Invoice-->
<script>

onload=myFunction();
onload=printDiv('invoice-POS');
function myFunction() {
  var person = prompt("Please enter your name", " ");
  if (person != null) {
    document.getElementById("demo").innerHTML =person;
  }
var dt = new Date();
document.getElementById("dt").innerHTML = dt.toLocaleString();
}
	function printDiv(divName){
			var printContents = document.getElementById(divName).innerHTML;
			var originalContents = document.body.innerHTML;

			document.body.innerHTML = printContents;

			window.print();

			document.body.innerHTML = originalContents;

		}

</script>
</body>

</html>