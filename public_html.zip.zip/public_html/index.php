<?php

	include "odsms_config.php";

	if(isset($_POST['submit'])){

	$uname = mysqli_real_escape_string($conn,$_POST['uname']);
	$password = mysqli_real_escape_string($conn,$_POST['pwd']);

	if ($uname != "" && $password != ""){

	$sql="SELECT * FROM employee WHERE username='$uname' AND password='$password'";
	$result = $conn->query($sql);
	$row = $result->fetch_row();
	if(!$row) {
	echo "<p style='color:red;'>Invalid username or password!</p>";
	}
	else if ($row[4]=='Salesman'){
		
		session_start();
		$_SESSION['uid']=$row[0];
		$_SESSION['user']=$row[2];
		header("location:salesmendashboard.php");
	}
	else if ($row[4]=="Store Manager"){

		session_start();
		$_SESSION['uid']=$row[0];
		$_SESSION['user']=$row[2];
		header("location:storemanagerdashboard.php");
	}
	else if ($row[4]=="City Manager"){

		session_start();
		$_SESSION['user']=$row[2];
		$_SESSION['uid']=$row[0];
	
		header("location:citymanager.php");
	}
	else if ($row[4]=="Country Manager"){

		session_start();
		$_SESSION['user']=$row[2];
		$_SESSION['uid']=$row[0];
		header("location:countrymanager.php");
	}
	else if ($row[4]=="CEO"){

		session_start();
		$_SESSION['user']=$row[2];
		$_SESSION['uid']=$row[0];

		header("location:ceo.php");
	}
	else if ($row[4]=="ADMIN"){

		session_start();
		$_SESSION['user']=$row[2];

		header("location:admin.php");
	}
	else 
	{echo "Username or Password is Incorrect!";}
	}
}?>
<!DOCTYPE html>

<html>
<head>
    	<link rel="stylesheet" href="2.css"/>
		<link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'/>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
		<script>$(document).ready(function(){
	$('.frame').click(function(){
		$('.top').addClass('open');
		$('.message').addClass('pull');
	})
});
        </script>

<title> ODSMS </title>

<style>

body{
	font-family:Arial;
	background-image:url("bg.png");
	background-size:cover;
	overflow:hidden;
}

.header {
  padding: 10px;
  margin:-10px;
  text-align: center;
  background: #003366;
  color: white;
  font-size: 30px;
}

.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: #003366;
   color: white;
   text-align: center;
}

.abc{
  color: dodgerblue;
  border: 2px solid black;
  background-color: #003366;
  color: white;
  padding: 14px 50px;
  font-size: 16px;
  cursor: pointer;
  border-radius:10px;
}


.abc a {
    color: white;
    text-decoration: none;
}

h1.lg {
	font-size: 150%;
    text-align: center;
	font-weight:bolder;
	text-shadow: 3px 0.1px white;
}
.modal {
	display: inline-block;
	position: fixed;
	z-index: 1; 
	left: 0;
	top: 40.5%;
	width: 100%;
	height: 100%;
	overflow: auto;
	background-color: rgb(0,0,0);
	background-color: rgba(0,0,0,0.4);
	padding-top: 60px;
}
.container{
    width:30%;
	margin:auto;
	background-color:white;
}
#div_login .textbox{
    width: 90%;
    padding: 7px;
}
h1.lg {
	font-size: 150%;
    text-align: center;
	font-weight:bolder;
	text-shadow: 3px 0.1px white;
}

#div_login{
    border:1px solid gray;
    border-radius: 3px;
    width: 30%px;
    height: 280px;
    box-shadow: 0px 2px 2px 0px  gray;
    margin: 0 auto;
}

#div_login h1{
    margin-top: 0px;
    font-weight: normal;
    padding: 10px;
    background-color: #003366;
    color: white;
    font-family: sans-serif;
}

#div_login div{
    clear: both;
    margin-top: 10px;
    padding: 5px;
	padding-right: 15px;
}

#div_login .textbox{
    width: 90%;
    padding: 7px;
}

input[type=submit]{
  background-color: #0077b3;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  display:inline-block;
  margin-top:5px;
}
/*csss for contact form start here*/

.frame{
	width: 600px;
	height: 350px;
	margin: 250px auto 0;
	position: relative;
	background: #435d77;
	border-radius:0 0 40px 40px; 
}
#button_open_envelope{
	width: 180px;
	height: 30px;
	position: absolute;
	z-index: 311;
	top: 250px;
	left: 208px;
	border-radius: 10px;
	color: #fff;
	font-size: 26px;
	padding:15px 0; 
	border: 2px solid #fff;
	transition:.3s;
}
#button_open_envelope:hover{
	background: #FFf;
	color: #2b67cb;
	transform:scale(1.1);
	transition:background .25s, transform .5s,ease-in;
	cursor: pointer;
}
.message{
	position: relative;
	width: 580px;
	min-height:300px;
	height: auto;
	background: #fff;
	margin: 0 auto;
	top: 30px;
	box-shadow: 0 0 5px 2px #333;
	transition:2s ease-in-out;
	transition-delay:1.5s;
	z-index: 300;
}
.left,.right,.top{width: 0;	height: 0;position:absolute;top:0;z-index: 310;}
.left{	
	border-left: 300px solid #337efc;
	border-top: 160px solid transparent;
	border-bottom: 160px solid transparent;
}
.right{	
	border-right: 300px solid #337efc;
	border-top: 160px solid transparent;
	border-bottom: 160px solid transparent;;
	left:300px;
}
.top{	
	border-right: 300px solid transparent;
	border-top: 200px solid #03A9F4;
	border-left: 300px solid transparent;
	transition:transform 1s,border 1s, ease-in-out;
	transform-origin:top;
	transform:rotateX(0deg);
	z-index: 500;
}
.bottom{
	width: 600px;
	height: 190px;
	position: absolute;
	background: #2b67cb;
	top: 160px;
	border-radius:0 0 30px 30px;
	z-index: 310; 
}

.open{
	transform-origin:top;
	transform:rotateX(180deg);
	transition:transform .7s,border .7s,z-index .7s ease-in-out;
	border-top: 200px solid #2c3e50;
	z-index: 200;
}
.pull{
	-webkit-animation:message_animation 2s 1 ease-in-out;
	animation:message_animation 2s 1 ease-in-out;
	-webkit-animation-delay:.9s;
	animation-delay:.45s;
	transition:1.5s;
	transition-delay:1s;
	z-index: 350;
}
#name,#email,#phone,#messarea,#send{
	margin: 0;
	padding: 0 0 0 10px;
	width: 570px;
	height:40px;
	float: left;
	display: block;
	font-size: 18px;
	color: #2b67cb;
	border:none;
	border-bottom:1px solid #bdbdbd;
	letter-spacing: normal;
}
#messarea{
	height: 117px;
	width: 560px;
	overflow: auto;
	border:none;
	padding: 10px;
}
#send{ 
	width:   580px;
	padding: 0;	
	border:  none;
	cursor:  pointer;
	background: #7CB342;
	color: #fff;
	transition:.35s;
	letter-spacing: 1px;
}
#send:hover{background:tomato;transition:.35s;}

::-moz-placeholder{color: #7CB342;font-family: 'Ubuntu';font-size: 20px;opacity: 1;} 
::-webkit-input-placeholder {color: #7CB342; font-family: 'Ubuntu';font-size: 20px;}
*:focus {outline: none;}
input:focus:invalid,textarea:focus:invalid {
 /* when a field is considered invalid by the browser */
    background: #fff url(images/invalid.png) no-repeat 98% center;
    box-shadow: 0 0 5px #d45252;
    border:1px solid #b03535;
}
input:required:valid,textarea:required:valid { 
	/* when a field is considered valid by the browser */
    background: #fff url(images/valid.png) no-repeat 98% center;
    box-shadow: 0 0 5px #5cd053;
    border-color: #28921f;
}


@-webkit-keyframes message_animation {
	0%{
		transform:translatey(0px);
		z-index: 300;
		transition: 1s ease-in-out;
	}
	50%{
		transform:translatey(-340px);
		z-index: 300;
		transition: 1s ease-in-out;
	}
	51%{
		transform:translatey(-340px);
		z-index: 350;
		transition: 1s ease-in-out;
	}
	100%{
		transform:translatey(0px);
		z-index: 350;
		transition: 1s ease-in-out;
	}
}
@keyframes message_animation {
	0%{
		transform:translatey(0px);
		z-index: 300;
		transition: 1s ease-in-out;
	}
	50%{
		transform:translatey(-340px);
		z-index: 300;
		transition: 1s ease-in-out;
	}
	51%{
		transform:translatey(-340px);
		z-index: 350;
		transition: 1s ease-in-out;
	}
	100%{
		transform:translatey(0px);
		z-index: 350;
		transition: 1s ease-in-out;
	}
}

/*csss for contact form end here*/
</style>

</head>
<body>
    

<div  class="header">
	<h1 > Online Drug Store Management System</h1>
	<p style="margin-top:-20px; line-height:1; font-size: 25px ">A project of Computer Science Student (S21024D6BD)</p>
</div>
<!-- Put this code anywhere in the body of your page where you want the badge to show up. -->

<div itemscope itemtype='http://schema.org/Person' class='fiverr-seller-widget' style='display: inline-block;'>
     <a itemprop='url' href=https://www.fiverr.com/obaidosm rel="nofollow" target="_blank" style='display: inline-block;'>
        <div class='fiverr-seller-content' id='fiverr-seller-widget-content-3e42cf00-aa52-4f0e-8a7b-cded20a1fa3f' itemprop='contentURL' style='display: none;'></div>
        <div id='fiverr-widget-seller-data' style='display: none;'>
            <div itemprop='name' >obaidosm</div>
            <div itemscope itemtype='http://schema.org/Organization'><span itemprop='name'>Fiverr</span></div>
            <div itemprop='jobtitle'>Seller</div>
            <div itemprop='description'>I'm Obaid Saeed graduated in 2017. New to Fiverr but experienced in Web Development,  WordPress, Complete SEO and Website Auditing. I have 3 years experience as a supervisor in rsfsoft company. Now i'm running a marketing company by my self and have a qualified working team under me. I can speak more than 7+ Language.
</div>
        </div>
    </a>
</div>

<script id='fiverr-seller-widget-script-3e42cf00-aa52-4f0e-8a7b-cded20a1fa3f' src='https://widgets.fiverr.com/api/v1/seller/obaidosm?widget_id=3e42cf00-aa52-4f0e-8a7b-cded20a1fa3f' data-config='{"category_name":"\n                                    Programming \u0026 Tech\n\n                            "}' async='true' defer='true'></script>

	<right><div class = "frame">
<div id = "button_open_envelope">
				Email me
			</div>
			<div class = "message">
				<form method="post" action="contact.php">
					<input type="text" name="name" id="name" placeholder=" Name* " required>
			
					<input type="email" name="email" id="email" placeholder=" Email* " required pattern="^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$">
				
					<input type="text" name="phone" id="phone" placeholder=" Phone (optional)" autofocus> 
				
					<textarea name="message" id="messarea" placeholder=" Message* " required></textarea>
			
					<input type="text" name="address" id="address" style="display: none;">
					<input type="submit" value="Send" id="send">
				</form>
			</div>
			<div class = "bottom"></div>			
			<div class = "left"></div>
			<div class = "right"></div>
			<div class = "top"></div>
			<script src="js/script.js"></script>
		</div>
		</right>
	

<div id="id01" class="modal">
	<form  method="post">
		<div class="container">
			<div id="div_login">
					<h1>Login To Store</h1>
		<center>
			<div>
				<input type="text" class="textbox" id="uname" name="uname" placeholder="Username" />
			</div>

			<div>
				<input type="password" class="textbox" id="pwd" name="pwd" placeholder="Password"/>
			</div>

			<div>
				<input type="submit" value="Submit" name="submit" id="submit" />
			</div>
		</center>
	
	</form>
</div>
</div>




	
		
</div>

<div class="footer">
	Developed by: Obaid & Awais
</div>


<!-- Put this code anywhere in the body of your page where you want the badge to show up. -->

<div itemscope itemtype='http://schema.org/Person' class='fiverr-seller-widget' style='display: inline-block;'>
     <a itemprop='url' href=https://www.fiverr.com/obaidosm rel="nofollow" target="_blank" style='display: inline-block;'>
        <div class='fiverr-seller-content' id='fiverr-seller-widget-content-3e42cf00-aa52-4f0e-8a7b-cded20a1fa3f' itemprop='contentURL' style='display: none;'></div>
        <div id='fiverr-widget-seller-data' style='display: none;'>
            <div itemprop='name' >obaidosm</div>
            <div itemscope itemtype='http://schema.org/Organization'><span itemprop='name'>Fiverr</span></div>
            <div itemprop='jobtitle'>Seller</div>
            <div itemprop='description'>I'm Obaid Saeed graduated in 2017. New to Fiverr but experienced in Web Development,  WordPress, Complete SEO and Website Auditing. I have 3 years experience as a supervisor in rsfsoft company. Now i'm running a marketing company by my self and have a qualified working team under me. I can speak more than 7+ Language.
</div>
        </div>
    </a>
</div>

<script id='fiverr-seller-widget-script-3e42cf00-aa52-4f0e-8a7b-cded20a1fa3f' src='https://widgets.fiverr.com/api/v1/seller/obaidosm?widget_id=3e42cf00-aa52-4f0e-8a7b-cded20a1fa3f' data-config='{"category_name":"\n                                    Programming \u0026 Tech\n\n                            "}' async='true' defer='true'></script>


</body>
</html>