<?php
		$conn = mysqli_connect("localhost", "id18771198_root", "Pakistan@786", "id18771198_odsms");
		if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
		}
?>